<?php
require_once('config/setting.php');
$virtual_con=mysqli_connect($hostname,$userdb,$passwd,$database);
?>
<?php
$title="Bean Bags"; //declare a variable
$content='';
$hostname='localhost';
$database='webproject';
$userdb='root';
$passwd='';
 ?>
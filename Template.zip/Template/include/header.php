<div class="header">
  <div id="header-container" class="container">
    <div class="headerdiv">
      <a href="" class="headerleft">
<img src="images/header.jpg" width="100%" height="102" alt="header">
   </a>
    </div>     
  </div>
</div> 